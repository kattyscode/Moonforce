# timingByPERank
基于PE估值分位数的择时策略：数据，回测程序