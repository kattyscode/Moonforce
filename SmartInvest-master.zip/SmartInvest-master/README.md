# SmartInvest
程序员的个人财富课实战例子

# Description
包含的子项目如下：
* smartMortgage 房贷的模拟程序
* investTable 投资跟踪表模版
* calendarStrategy 日历效应策略的数据，回测程序和分析结果
* quantTrading 量化投资系统实战项目