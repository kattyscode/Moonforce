# trendStrategy
趋势跟踪策略回测：数据，回测程序